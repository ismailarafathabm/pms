import compreheciverpt from "./controllers/index.js";
app.controller('compreheciverpt', compreheciverpt);

