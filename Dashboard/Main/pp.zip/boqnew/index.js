import Autorizationctrl from "./js/controllers/auth.js";
app.controller("autorizationctrl", Autorizationctrl);

import morelease from "./js/controllers/morelease.js";
app.controller("morelease", morelease);

