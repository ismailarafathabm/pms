import nbom from './controllers/index.js';
app.controller("nbom", nbom);

import nbomnew from './controllers/new.js';
app.controller('nbomnew', nbomnew);

import nbomrpt from './controllers/bomrpt.js';
app.controller('nbomrpt', nbomrpt);