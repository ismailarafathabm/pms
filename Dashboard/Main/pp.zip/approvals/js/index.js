import technicalsubmital from "./controllers/technicalsubmital.js";
app.controller('technicalsubmital', technicalsubmital);

import technicalsubmitalnew from "./controllers/technicalsubmitalnew.js";
app.controller('technicalsubmitalnew', technicalsubmitalnew);

import shopdrawingsubmital from './controllers/shopdrawingapprovals.js';
app.controller("shopdrawingsubmital", shopdrawingsubmital);

import shopdrawingsubmitalnew from './controllers/shopdrawingsubmitalnew.js';
app.controller('shopdrawingsubmitalnew', shopdrawingsubmitalnew);