<style>
    #projectfilters {
        display: block;
        width: 532px;
        position: absolute;
        top: -2px;
        left : 0;
        background: #f5f5f5;
        padding: 5px;
        border-radius: 5px;
        border: 1px solid #b9b9b9;
        z-index: 50;
        height: 210px;
    }
</style>