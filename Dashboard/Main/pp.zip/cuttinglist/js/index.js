
import cuttinglistsnew from "./controllers/new.js";
app.controller('cuttinglistsnew', cuttinglistsnew);

import Cuttinglistsimport from "./controllers/indeximport.js";
app.controller('Cuttinglistsimport', Cuttinglistsimport);

import Cuttinglists from "./controllers/index.js";
app.controller('cuttinglists', Cuttinglists);

import enggo from "./controllers/go.js";
app.controller('enggo', enggo);

import enggonew from "./controllers/gonew.js";
app.controller('enggonew', enggonew);

import Cuttinglistsusers from "./controllers/indexuser.js";
app.controller('cuttinglistsusers', Cuttinglistsusers);

import cuttinglistsp from "./controllers/indexp.js";
app.controller('cuttinglistsp', cuttinglistsp);

import cuttinglistsusersp from "./controllers/indexuserp.js";
app.controller('cuttinglistsusersp', cuttinglistsusersp);

import cuttinglistsusersdt from './controllers/indexuserdt.js';
app.controller('cuttinglistsusersdt', cuttinglistsusersdt)

import cuttinglistsupdates from './controllers/bulkupdate.js';
app.controller('cuttinglistsupdates', cuttinglistsupdates);