<?php 
    $materialstatus = [
        'AVI',
        'WH',
        'PP',
        'STRIP',
        'A.C.MO',
        'ORD',
    ]
?>