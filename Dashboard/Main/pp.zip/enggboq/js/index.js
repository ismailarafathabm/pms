import boqrelease from './controllers/boqrelease.js';
app.controller('boqrelease', boqrelease);

import boqsummary from './controllers/index.js';
app.controller('boqsummary', boqsummary);

import engreleasesummary  from './controllers/engreleasesummary.js';
app.controller('engreleasesummary', engreleasesummary);