import projectctrl from './controllers/index.js';
app.controller('projectctrl',projectctrl)