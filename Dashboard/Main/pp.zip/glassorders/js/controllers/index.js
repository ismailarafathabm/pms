import GoServices from './../services/index.js';
export default function gorptcontroller($scope, $rootScope, $filter, $compile) {
    document.getElementById("glassorderss").classList.add('menuactive');
    const gs = new GoServices();
    

}