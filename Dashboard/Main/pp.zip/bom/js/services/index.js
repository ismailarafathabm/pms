import WhServices from "./wh.js";

export default class WH extends WhServices{
    #page = "items";
    
}