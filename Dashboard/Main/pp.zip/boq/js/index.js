import boqopenew from "./controllers/new.js";
app.controller('boqopenew', boqopenew);

import boqope from './controllers/index.js';
app.controller('boqope', boqope);

import boqopenewa from "./controllers/newa.js";
app.controller('boqopenewa',boqopenewa)